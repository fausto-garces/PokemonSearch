const configUrl = 'assets/config.json';

function getConfig() {
  return this.http.get(this.configUrl);
}
