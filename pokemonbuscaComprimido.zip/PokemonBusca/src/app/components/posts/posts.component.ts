import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {saveAs} from 'file-saver';



@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  constructor(private http: HttpClient) { }

  filterPost = '';
  posts = [ ];

ngOnInit() {

    const obs =  this.http.get('http://localhost:5000/WeatherForecast/');
    let result;
    obs.subscribe((response) => {
      result = response;
      console.log(response);
      this.posts = result.results;
    }

    );

 }
 downloadFile(url: string, name: string) {
  this.http.get(url, {responseType: 'blob', headers: {Accept: 'application/pdf'}})
  .subscribe((blob: string | Blob) => {
    saveAs(blob, 'Detalle_' + name + '.txt');
  });
 }

}
